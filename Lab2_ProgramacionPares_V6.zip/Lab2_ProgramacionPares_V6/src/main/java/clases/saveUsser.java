/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;

/**
 *
 * @author HP
 */
public class saveUsser {
    openMongo iM = new openMongo();
   public void validData(String nameU, String lastname, String passwordU, String password1U, String idU, String telU, String country,JTextField name,JTextField lastName,JTextField password,JTextField password1,JTextField id,JTextField cell){
   if (nameU.isEmpty() || lastname.isEmpty() ||passwordU.isEmpty() || password1U.isEmpty() || idU.isEmpty() ||telU.isEmpty() || country.isEmpty()) {
           JOptionPane.showMessageDialog(null, "Debes llenar todos los campos","Campos vacios",JOptionPane.WARNING_MESSAGE);     
          return;}
       try{
        if (!idU.matches("\\d{10}")) {
          JOptionPane.showMessageDialog(null, "Ingrese una cedula válida", "Error", JOptionPane.ERROR_MESSAGE);
          return;
        }} catch (NumberFormatException e) {
         JOptionPane.showMessageDialog(null, "Ingrese una cedula válida", "Error", JOptionPane.ERROR_MESSAGE);
         return;
    } 
   try{
        if (!telU.matches("\\d{10}")) {
          JOptionPane.showMessageDialog(null, "Ingrese un numero de telefono válido (10 dígitos)", "Error", JOptionPane.ERROR_MESSAGE);
          return;
        }} catch (NumberFormatException e) {
         JOptionPane.showMessageDialog(null, "Ingrese un mumero válido", "Error", JOptionPane.ERROR_MESSAGE);
         return;
    } 
    if (!nameU.matches("[a-zA-Z]+")) {
            JOptionPane.showMessageDialog(null, "Ingrese un nombre valido (Sin numeros)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    if (!lastname.matches("[a-zA-Z]+")) {
            JOptionPane.showMessageDialog(null, "Ingrese un apellido valido (Sin numeros)", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    if (!passwordU.equals(password1U)){
        JOptionPane.showMessageDialog(null, "Las contraseñas ingresadas no coinciden", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
   saveClient( nameU, lastname, passwordU, password1U, idU, telU, country, name, lastName, password, password1, id, cell);
 }
    public void saveClient(String nameU, String lastname, String passwordU, String password1U, String idU, String telU, String country ,JTextField name,JTextField lastName,JTextField password,JTextField password1,JTextField id,JTextField cell){
        iM.openMongo();
        MongoDatabase database = iM.getDatabase();
        MongoCollection<Document> collection = database.getCollection("usuarios");
        Document filter = new Document("Cédula:", idU);
        Document query = new Document("Teléfono:", telU);
        FindIterable<Document> result = collection.find(filter);
        FindIterable<Document> results = collection.find(query);
        if (result.iterator().hasNext()) {
            JOptionPane.showMessageDialog(null, "La cédula ingresada ya existe dentro del registro, porfavor, ingrese datos distintos", "Error", JOptionPane.ERROR_MESSAGE);                    
            return;
        } 
        if (results.iterator().hasNext()) {
            JOptionPane.showMessageDialog(null, "El número de teléfono ingresado ya existe dentro del registro, porfavor, ingrese datos distintos", "Error", JOptionPane.ERROR_MESSAGE);                   
            return;
        } else {    
         Document documents= new Document().append("Usuario", nameU + " "+ lastname).append("Contraseña", passwordU).append("Cédula", idU).append("Teléfono", telU).append("Ciudad", country);
         collection.insertOne(documents);
         JOptionPane.showMessageDialog(null, "Datos guardados correctamente en la base de datos", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        }
        cleanText( name, lastName, password, password1, id, cell);
        
    }
    public void cleanText(JTextField name,JTextField lastName,JTextField password,JTextField password1,JTextField id,JTextField cell){
        name.setText("");
    lastName.setText("");
    password.setText("");
    password1.setText("");
    id.setText("");
    cell.setText("");
    }
}

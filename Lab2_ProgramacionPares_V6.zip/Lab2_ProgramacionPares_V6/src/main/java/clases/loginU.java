/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mycompany.lab2_programacionpares.principal;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import org.bson.Document;

/**
 *
 * @author HP
 */
public class loginU {
    openMongo iM = new openMongo();
     public void controlDatos(String userID, String password, JPanel jPanel6, JPanel jPanel4){
         if (!userID.matches("\\d{10}")) {
            JOptionPane.showMessageDialog(null, "La cédula debe contener exactamente 10 dígitos numéricos", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        contolID( userID,  password, jPanel6,jPanel4);
    }
    public void contolID(String userID, String password,JPanel jPanel6, JPanel jPanel4){
        iM.openMongo();
        MongoDatabase database = iM.getDatabase();
        MongoCollection<Document> collection = database.getCollection("usuarios");
        Document query = new Document("Cédula", userID);
    Document queryD = new Document("Contraseña", password);
    long count= collection.countDocuments(query);
    long countD= collection.countDocuments(queryD);
        if(count<=0){
            JOptionPane.showMessageDialog(null, "La cedula ingresada no esta registrada", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }else{
         if(countD<=0){
            JOptionPane.showMessageDialog(null, "La contraseña ingresada es incorrecta", "Error", JOptionPane.ERROR_MESSAGE);            
            return;
        }else{
             jPanel4.setVisible(true);
             jPanel6.setVisible(false);
             
         }
        }
    }
}

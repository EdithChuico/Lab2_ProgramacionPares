/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package boletos;

import javax.swing.JTextField;


/**
 *
 * @author USER
 */
abstract public class Boletos {
    public abstract void cantBoletos(double price, JTextField cont, JTextField contPrice);
}

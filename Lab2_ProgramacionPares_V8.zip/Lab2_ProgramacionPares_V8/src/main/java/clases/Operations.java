/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import javax.swing.JTextField;

/**
 *
 * @author USER
 */
public class Operations {
    public void resta(JTextField cont, JTextField contPrice, double price){
        int base=Integer.parseInt(cont.getText());
        int newCont;
        if(base==0){
            newCont=0;
        }else{
            newCont=base-1;
        }
        String NewCont=String.valueOf(newCont);
        cont.setText(NewCont);
        double contprice=newCont*price;
        contPrice.setText(String.valueOf(contprice));
    }
    public void suma(JTextField cont, JTextField contPrice, double price){
        int base=Integer.parseInt(cont.getText());
        int newCont=base+1;
        String NewCont=String.valueOf(newCont);
        cont.setText(NewCont);
        double contprice=newCont*price;
        contPrice.setText(String.valueOf(contprice));
    }
}

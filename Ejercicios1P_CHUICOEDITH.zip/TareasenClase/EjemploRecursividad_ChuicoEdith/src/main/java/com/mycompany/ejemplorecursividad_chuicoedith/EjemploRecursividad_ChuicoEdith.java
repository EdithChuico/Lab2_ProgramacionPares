package com.mycompany.ejemplorecursividad_chuicoedith;

import java.util.Scanner;

public class EjemploRecursividad_ChuicoEdith {

    public static void main(String[] args) {
      Scanner s=new Scanner(System.in);
      int a, b;
      //Solicita el numero de la tabla de multilpicar
      System.out.println("Ingrese el numero del que desee la tabla de multiplicar:");
      a=s.nextInt();
      //Pide ingreso de las veces que se desee multiplicar el numero
      System.out.println("Ingrese las veces que desee multiplicar el numero");
      b=s.nextInt();
      //Envia los datos ingresador y el numero 1 como inicio de un indice iterador
      multiplicacion(a,b,1);
      
    }
    public static void multiplicacion(int multiplicando, int multiplicador, int i){
        //Recibe del main el multiplicando y las veces a multiplicar, junto con i ( el indice iterador) 
        if (i <= multiplicador) {
            //Si i es menor o igual que el numero de veces que se espera multiplicar, se va a 
            //imprimir la multiplicacion
            System.out.println(multiplicando + " x " + i + " = " + (multiplicando * i));
            // envia al método cantidad el numero a mutiplicar, el multiplicador y 
            //las veces a multiplicar + 1 
            cantidad(multiplicando, multiplicador, i + 1);
        }
    }
    public static void cantidad(int multiplicando, int multiplicador, int i){
       //Llama al método multiplicacion con el indice i ya incrementado
       //RECURSIVIDAD INDIRECTA
        multiplicacion(multiplicando,multiplicador,i);  
    }
}

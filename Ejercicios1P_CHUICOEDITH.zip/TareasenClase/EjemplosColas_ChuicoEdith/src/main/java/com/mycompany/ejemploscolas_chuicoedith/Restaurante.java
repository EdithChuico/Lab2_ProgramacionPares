
package com.mycompany.ejemploscolas_chuicoedith;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;
import javax.swing.DefaultListModel;
public class Restaurante {
    public Stack<Queue<String>> pedidosPendientes;
    public  Queue<String> pedidosPreparados;
    public MongoCollection<Document> collection;
    public DefaultListModel<String> listModel;
    //Constructor
    public Restaurante() {
        pedidosPendientes = new Stack<>();
        pedidosPreparados = new LinkedList<>();
        MongoClient mc = MongoClients.create("mongodb://localhost:27017/");
        MongoDatabase db = mc.getDatabase("Lab2");
        collection = db.getCollection("Pedidos");
    }
    // Método para cargar pedidos desde la base de datos
    public void cargarPedidosDesdeBD() {
        for (Document doc : collection.find()) {
            Queue<String> pedido = new LinkedList<>();
            for (Object item : (Iterable<?>) doc.get("Pedido")) {
                pedido.add(item.toString());
            }
            pedidosPendientes.push(pedido);
            
        }
    }
    // Método para preparar el pedido actual
    public void prepararPedidoActual( ) {
        if (!pedidosPendientes.isEmpty()) {
            Queue<String> pedidoActual = pedidosPendientes.pop();
            pedidosPreparados.addAll(pedidoActual);
    }
    }
    public Queue<String> getPedidosPreparados() {
        return pedidosPreparados;
    }

    // Método para acceder a pedidosPendientes
    public Stack<Queue<String>> getPedidosPendientes() {
        return pedidosPendientes;
    }
    
}

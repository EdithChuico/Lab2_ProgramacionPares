/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.ejemploscolas_chuicoedith;

import com.mongodb.BasicDBObject;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import javax.swing.JOptionPane;
import org.bson.Document;
public class PrepararPedido extends javax.swing.JFrame {
    public PrepararPedido() {
           initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pasarPedidosPreparados = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        verPedidoActual = new javax.swing.JButton();
        lista = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pasarPedidosPreparados.setBorder(null);
        pasarPedidosPreparados.setOpaque(false);
        pasarPedidosPreparados.setContentAreaFilled(false);
        pasarPedidosPreparados.setBorderPainted(false);
        pasarPedidosPreparados.setText("Pasar a pedidos preparados");
        pasarPedidosPreparados.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        pasarPedidosPreparados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasarPedidosPreparadosActionPerformed(evt);
            }
        });
        getContentPane().add(pasarPedidosPreparados, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 170, 200, 30));

        jButton2.setBorder(null);
        jButton2.setOpaque(false);
        jButton2.setContentAreaFilled(false);
        jButton2.setBorderPainted(false);
        jButton2.setText("volver");
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 90, 30));

        jLabel1.setText("Pedido a preparar: ");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 60, -1, -1));

        verPedidoActual.setText("Ver pedido actual");
        verPedidoActual.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                verPedidoActualActionPerformed(evt);
            }
        });
        getContentPane().add(verPedidoActual, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 60, -1, -1));
        getContentPane().add(lista, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 410, 30));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void pasarPedidosPreparadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasarPedidosPreparadosActionPerformed
      MongoClient mc = MongoClients.create("mongodb://localhost:27017/");
        MongoDatabase db = mc.getDatabase("Lab2");
        MongoCollection<Document> pedidosCollection = db.getCollection("Pedidos");
        MongoCollection<Document> historialCollection = db.getCollection("Pedidos Preparados");
        FindIterable<Document> iterable = pedidosCollection.find().sort(new BasicDBObject("_id", -1)).limit(1);
        Document latestPedido = iterable.first();
        if (latestPedido != null) {
            historialCollection.insertOne(latestPedido);
            pedidosCollection.deleteOne(Filters.eq("_id", latestPedido.getObjectId("_id")));
            JOptionPane.showMessageDialog(this, "Pedido eliminado de la lista, y cambiado a pedidos preparados", "Exito", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_pasarPedidosPreparadosActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        Principal_1 p=new Principal_1();
        p.setVisible(true);
        p.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void verPedidoActualActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_verPedidoActualActionPerformed
    MongoClient mc = MongoClients.create("mongodb://localhost:27017/");
MongoDatabase db = mc.getDatabase( "Lab2");
MongoCollection <Document> cl=db.getCollection("Pedidos");
FindIterable<Document> iterable = cl.find().sort(new BasicDBObject("_id", -1)).limit(1);
for (Document doc : iterable) {
    String pedido = doc.get("Pedido") != null ? doc.get("Pedido").toString() : "No hay pedido";
    lista.setText(pedido);
}
    }//GEN-LAST:event_verPedidoActualActionPerformed
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PrepararPedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PrepararPedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PrepararPedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PrepararPedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PrepararPedido().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JTextField lista;
    private javax.swing.JButton pasarPedidosPreparados;
    private javax.swing.JButton verPedidoActual;
    // End of variables declaration//GEN-END:variables
}

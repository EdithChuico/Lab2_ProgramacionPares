package com.mycompany.ejemploscolas_chuicoedith;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javax.swing.JOptionPane;
import org.bson.Document;
public class Producto {
  public String nombre;
  public double precio;
  public int cantidad;
    public Producto(String nombre, double precio, int cantidad) {
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
    } 
  public void agregarProducto(String name, String precioProd, String cantidadProd){
       if (name.isEmpty() || precioProd.isEmpty() || cantidadProd.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Todos los campos deben estar llenos", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    try {
        precio = Double.parseDouble(precioProd);
        if (precio <= 0) {
            JOptionPane.showMessageDialog(null, "El precio debe ser un número positivo", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "El precio debe ser un número válido", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }   
    try {
        cantidad = Integer.parseInt(cantidadProd);
        if (cantidad <= 0) {
            JOptionPane.showMessageDialog(null, "La cantidad debe ser un número entero positivo", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "La cantidad debe ser un número entero válido", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    MongoClient mc = MongoClients.create("mongodb://localhost:27017/");
    MongoDatabase db = mc.getDatabase( "Lab2");
    MongoCollection <Document> cl=db.getCollection("Productos");
    Document doc=new Document().append("Producto", name).append("Precio", precioProd).append("Cantidad", cantidad);
    cl.insertOne(doc);
    JOptionPane.showMessageDialog(null, "Producto Registrado", "Exito", JOptionPane.INFORMATION_MESSAGE);
 
  }
}

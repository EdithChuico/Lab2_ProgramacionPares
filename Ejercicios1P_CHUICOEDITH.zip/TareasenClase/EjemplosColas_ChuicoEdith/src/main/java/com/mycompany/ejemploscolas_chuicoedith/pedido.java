package com.mycompany.ejemploscolas_chuicoedith;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;

public class pedido extends javax.swing.JFrame {

    public pedido() {
        initComponents();
        DefaultTableModel tabla1= (DefaultTableModel) listaPedido.getModel();
        tabla1.setRowCount(0);    
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jComboBox2 = new javax.swing.JComboBox<>();
        buttonGroup1 = new javax.swing.ButtonGroup();
        nombre = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        listaMenu = new javax.swing.JList<>();
        cantidadMenu = new javax.swing.JSpinner();
        numPedido = new javax.swing.JSpinner();
        jButton3 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        listaPedido = new javax.swing.JTable();
        Actualizar = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        nombre.setBorder(null);
        getContentPane().add(nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 120, 200, -1));

        jButton1.setBorder(null);
        jButton1.setOpaque(false);
        jButton1.setContentAreaFilled(false);
        jButton1.setBorderPainted(false);
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 370, 140, 30));

        jButton2.setBorder(null);
        jButton2.setOpaque(false);
        jButton2.setContentAreaFilled(false);
        jButton2.setBorderPainted(false);
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 80, 20));

        listaMenu.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { " " };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(listaMenu);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 160, 170, 90));
        getContentPane().add(cantidadMenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 160, 80, -1));
        getContentPane().add(numPedido, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 150, 230, 30));

        jButton3.setBorder(null);
        jButton3.setOpaque(false);
        jButton3.setContentAreaFilled(false);
        jButton3.setBorderPainted(false);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 210, 130, 30));

        listaPedido.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Platillo", "Cantidad", "Precio Unidad"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(listaPedido);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 260, 300, 100));

        Actualizar.setBorder(null);
        Actualizar.setOpaque(false);
        Actualizar.setContentAreaFilled(false);
        Actualizar.setBorderPainted(false);
        Actualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ActualizarActionPerformed(evt);
            }
        });
        getContentPane().add(Actualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 130, 110, 20));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/agregarPedidos.png"))); // NOI18N
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(-3, 0, 760, 440));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    String name = nombre.getText();
    int numPed = (int) numPedido.getValue();
    MongoClient mc = MongoClients.create("mongodb://localhost:27017/");
    MongoDatabase db = mc.getDatabase("Lab2");
    MongoCollection<Document> clPedidos = db.getCollection("Pedidos");
    MongoCollection<Document> clProductos = db.getCollection("Productos");
    DefaultTableModel modeloTabla = (DefaultTableModel) listaPedido.getModel();
    int rowCount = modeloTabla.getRowCount();
    Queue<String> cola = new LinkedList<>();
    List<Document> pedidoItems = new ArrayList<>();
    for (int i = 0; i < rowCount; i++) {
        String nombrePlatillo = (String) modeloTabla.getValueAt(i, 0);
        int cantidad = (int) modeloTabla.getValueAt(i, 1);
        double precio = (double) modeloTabla.getValueAt(i, 2);
        Document itemPedido = new Document("Nombre", nombrePlatillo)
                .append("Cantidad", cantidad)
                .append("Precio", precio);
        pedidoItems.add(itemPedido);
        String fila = "Nombre: " + nombrePlatillo + ", Cantidad: " + cantidad + ", Precio: " + precio;
        cola.add(fila);
        Document query = new Document("Producto", nombrePlatillo);
        Document producto = clProductos.find(query).first();
    }
    Document pedidoDoc = new Document("Nombre del cliente", name)
            .append("Numero de pedido", numPed)
            .append("Pedido", pedidoItems);
    clPedidos.insertOne(pedidoDoc);
    JOptionPane.showMessageDialog(null, "Pedido Guardado Exitosamente", "Exito", JOptionPane.INFORMATION_MESSAGE);
    Restaurante restaurante = new Restaurante();
    restaurante.cargarPedidosDesdeBD();    
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
    Principal_1 p=new Principal_1();
     p.setVisible(true);
    p.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
         String name=nombre.getText();
        int numPed= (int)numPedido.getValue();
        String menu= listaMenu.getSelectedValue();
        int numMenu= (int)cantidadMenu.getValue();
        double precio=0;
         Pedidos p=new Pedidos(numPed, name);
         p.agregarProducto( menu,  numMenu,  precio,  listaPedido );
    }//GEN-LAST:event_jButton3ActionPerformed

    private void ActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ActualizarActionPerformed
        MongoClient mc = MongoClients.create("mongodb://localhost:27017/");
        MongoDatabase db = mc.getDatabase("Lab2");
        MongoCollection<Document> cl = db.getCollection("Productos");
    DefaultListModel<String> modeloLista = new DefaultListModel<>();
       for (Document doc : cl.find()) {
        String producto = doc.getString("Producto");
        Object precioObj = doc.get("Precio");
        double precio = 0.0;
        if (precioObj instanceof Double) {
            precio = (Double) precioObj;
        } else if (precioObj instanceof Integer) {
            precio = ((Integer) precioObj).doubleValue();
        } else if (precioObj instanceof String) {
            try {
                precio = Double.parseDouble((String) precioObj);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Error al convertir el precio del producto: " + producto, "Error", JOptionPane.ERROR_MESSAGE);
                continue;
            }
        }
        String item = producto + " $" + precio;
        modeloLista.addElement(item);
    }
    listaMenu.setModel(modeloLista);
    }//GEN-LAST:event_ActualizarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(pedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(pedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(pedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(pedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new pedido().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Actualizar;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JSpinner cantidadMenu;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JList<String> listaMenu;
    private javax.swing.JTable listaPedido;
    private javax.swing.JTextField nombre;
    private javax.swing.JSpinner numPedido;
    // End of variables declaration//GEN-END:variables
}

package com.mycompany.ejemploscolas_chuicoedith;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;
public class Plato {
    public void mostrarDetallesPedido(JTable de){
         MongoClient mc = MongoClients.create("mongodb://localhost:27017/");
        MongoDatabase db = mc.getDatabase( "Lab2");
        MongoCollection <Document> clP=db.getCollection("Pedidos");
        DefaultTableModel tabla1=new DefaultTableModel();
        tabla1.setColumnIdentifiers(new String []{"Cleinte", "Numero de pedido","Pedido"});
        FindIterable <Document> documentos= clP.find();
        for (Document doc:documentos){
        tabla1.addRow(new Object[]{
             doc.get("Nombre del cliente"),
             doc.get("Numero de pedido"),
             doc.get("Pedido")});
         }de.setModel(tabla1);
    }
    public void eliminar(String num){
       int cantidad;
        try {
        cantidad = Integer.parseInt(num);
        if (cantidad <= 0) {
            JOptionPane.showMessageDialog(null, "La cantidad debe ser un número entero positivo", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "La cantidad debe ser un número entero válido", "Error", JOptionPane.ERROR_MESSAGE);
        return; }
        MongoClient mc = MongoClients.create("mongodb://localhost:27017/");
       MongoDatabase db = mc.getDatabase( "Lab2");
       MongoCollection <Document> clP=db.getCollection("Pedidos");
       Document query=new Document("Numero de pedido", cantidad);
       clP.deleteOne(query);
       JOptionPane.showMessageDialog(null, "Pedido Eliminado", "Exito", JOptionPane.INFORMATION_MESSAGE);
    }
}

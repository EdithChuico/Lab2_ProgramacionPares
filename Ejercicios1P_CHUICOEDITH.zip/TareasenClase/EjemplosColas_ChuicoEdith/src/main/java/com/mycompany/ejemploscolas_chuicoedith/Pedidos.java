package com.mycompany.ejemploscolas_chuicoedith;
import java.util.LinkedList;
import java.util.Queue;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
public class Pedidos {
    public int numeroPedido;
    public String nombreCliente;
    Queue<String> productos = new LinkedList<>();

    public Pedidos(int numeroPedido, String nombreCliente) {
        this.numeroPedido = numeroPedido;
        this.nombreCliente = nombreCliente;
    }
  public void agregarProducto(String menu, int numMenu, double precio, JTable listaPedido ){
    DefaultTableModel modeloTabla = (DefaultTableModel) listaPedido.getModel();
        String[] parts = menu.split("\\$");
        String nombrePlatillo = parts[0].trim();
        double precioUnidad = Double.parseDouble(parts[1].trim());

        Object[] fila = {nombrePlatillo, numMenu, precioUnidad};
        modeloTabla.addRow(fila);
    } 
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejemploscolas_chuicoedith;

public class EjemplosColas_ChuicoEdith {

    public static void main(String[] args) {
   Principal_1 p=new Principal_1();
   p.setVisible(true);
   p.setLocationRelativeTo(null);
  Restaurante restaurante = new Restaurante();
    restaurante.cargarPedidosDesdeBD();
    
}}
    


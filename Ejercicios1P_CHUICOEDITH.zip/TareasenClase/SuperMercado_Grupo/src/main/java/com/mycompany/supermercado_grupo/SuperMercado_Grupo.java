
package com.mycompany.supermercado_grupo;
import java.util.Scanner;

public class SuperMercado_Grupo {
    public static void main(String[] args) {
        menu b=new menu();
        b.setVisible(true);
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese el número de cajas: ");
        int numCajas = scanner.nextInt();
        Supermercado supermercado = new Supermercado(numCajas);
        int opcion;
        do{
            System.out.println("\nMenú:");
            System.out.println("1. Adicionar nuevo cliente a la cola de una caja.");
            System.out.println("2. Atender cliente en una caja.");
            System.out.println("3. Visualizar estado de las colas.");
            System.out.println("4. Adicionar nuevo producto al supermercado.");
            System.out.println("5. Adicionar stock a un producto.");
            System.out.println("6. Visualizar stock de productos.");
            System.out.println("7. Mostrar menú nuevamente.");
            System.out.println("0. Salir.");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar el buffer

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el número de la caja: ");
                    int numCaja = scanner.nextInt();
                    Cliente cliente = new Cliente();
                    supermercado.adicionarClienteACaja(numCaja, cliente);
                    break;
                case 2:
                    System.out.print("Ingrese el número de la caja: ");
                    int numCajaAtender = scanner.nextInt();
                    supermercado.atenderClienteEnCaja(numCajaAtender);
                    break;
                case 3:
                    supermercado.visualizarEstadoColas();
                    break;
                case 4:
                    System.out.print("Ingrese el nombre del producto: ");
                    String nombreProducto = scanner.nextLine();
                    supermercado.adicionarProducto(nombreProducto);
                    break;
                case 5:
                    System.out.print("Ingrese el nombre del producto: ");
                    String nombreProductoStock = scanner.nextLine();
                    System.out.print("Ingrese la cantidad de stock: ");
                    int cantidadStock = scanner.nextInt();
                    supermercado.adicionarStockProducto(nombreProductoStock, cantidadStock);
                    break;
                case 6:
                    supermercado.visualizarStockProductos();
                    break;
                case 7:
                    break;
                case 0:
                    System.out.println("Saliendo del sistema...");
                    return;
                default:
                    System.out.println("Opción no válida.");
                    break;
            }
        }while(opcion!=0);
    }
}
package com.mycompany.supermercado_grupo;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

class Cliente {
    private static int idCounter = 1;
    private int id;
    public Cliente() {
        this.id = idCounter++;
    }
    public int getId() {
        return id;
    }
    @Override
    public String toString() {
        return "Cliente{" + "id=" + id + '}';
    }
}
class Caja {
    private Queue<Cliente> colaClientes = new LinkedList<>();
    public void adicionarCliente(Cliente cliente) {
        colaClientes.add(cliente);
    }
    public Cliente atenderCliente() {
        return colaClientes.poll();
    }
    public Queue<Cliente> getColaClientes() {
        return colaClientes;
    }
    @Override
    public String toString() {
        return "Caja{" + "colaClientes=" + colaClientes + '}';
    }
}
class Producto {
    private String nombre;
    private Stack<Integer> stock = new Stack<>();
    public Producto(String nombre) {
        this.nombre = nombre;
    }
    public String getNombre() {
        return nombre;
    }
    public void adicionarStock(int cantidad) {
        for (int i = 0; i < cantidad; i++) {
            stock.push(1);
        }
    }
    public int getStockSize() {
        return stock.size();
    }

    @Override
    public String toString() {
        return "Producto{" + "nombre='" + nombre + '\'' + ", stock=" + stock.size() + '}';
    }
}

public class Supermercado {
    private ArrayList<Caja> cajas;
    private ArrayList<Producto> productos;

    public Supermercado(int numCajas) {
        cajas = new ArrayList<>(numCajas);
        for (int i = 0; i < numCajas; i++) {
            cajas.add(new Caja());
        }
        productos = new ArrayList<>();
    }

    public void adicionarClienteACaja(int numCaja, Cliente cliente) {
        if (numCaja >= 0 && numCaja < cajas.size()) {
            cajas.get(numCaja).adicionarCliente(cliente);
        } else {
            System.out.println("Número de caja no válido.");
        }
    }

    public void atenderClienteEnCaja(int numCaja) {
        if (numCaja >= 0 && numCaja < cajas.size()) {
            Cliente clienteAtendido = cajas.get(numCaja).atenderCliente();
            if (clienteAtendido != null) {
                System.out.println("Cliente atendido: " + clienteAtendido);
            } else {
                System.out.println("No hay clientes en la cola de la caja " + numCaja);
            }
        } else {
            System.out.println("Número de caja no válido.");
        }
    }

    public void visualizarEstadoColas() {
        for (int i = 0; i < cajas.size(); i++) {
            System.out.println("Caja " + i + ": " + cajas.get(i).getColaClientes());
        }
    }

    public void adicionarProducto(String nombre) {
        productos.add(new Producto(nombre));
    }

    public void adicionarStockProducto(String nombre, int cantidad) {
        for (Producto producto : productos) {
            if (producto.getNombre().equalsIgnoreCase(nombre)) {
                producto.adicionarStock(cantidad);
                System.out.println("Stock añadido exitosamente.");
                return;
            }
        }
        System.out.println("Producto no encontrado.");
    }

    public void visualizarStockProductos() {
        for (Producto producto : productos) {
            System.out.println(producto);
        }
    }

    public ArrayList<Caja> getCajas() {
        return cajas;
    }

    public ArrayList<Producto> getProductos() {
        return productos;
    }
}


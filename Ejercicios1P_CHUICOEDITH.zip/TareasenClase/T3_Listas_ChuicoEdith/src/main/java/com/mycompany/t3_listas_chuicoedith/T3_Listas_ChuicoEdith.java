package com.mycompany.t3_listas_chuicoedith;
import java.util.ArrayList;
import java.util.Scanner;

public class T3_Listas_ChuicoEdith {
    // Esta clase define el medicamento con su precio
    public static class Medicina {
        // Atributos
        String medicamento;
        float precio;
        // Constructor
        public Medicina(String medicamento, float precio) {
            this.medicamento = medicamento;
            this.precio = precio;
        }
        // Devolver el nombre del medicamento
        public String getMedicina() {
            return medicamento;
        }
        @Override
        public String toString() {
            return "Medicinas{" + "medicamento=" + medicamento + ", precio=" + precio + '}';
        }
    }
    // Lista para almacenar los productos
    private static ArrayList<Medicina> listaMedicina = new ArrayList<>();
    // Leer entrada de datos
    private static Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) {
        int opcion;
        do {
            System.out.println("\nGestión de Farmacia:");
            System.out.println("1. Añadir Medicamento");
            System.out.println("2. Eliminar Medicamento");
            System.out.println("3. Listar Medicamentos");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();
            switch (opcion) {
                case 1:
                    añadirMedicina();
                    break;
                case 2:
                    eliminarMedicina();
                    break;
                case 3:
                    listarMedicinas();
                    break;
                case 4:
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Opción no válida, por favor intente nuevamente.");
            }
        } while (opcion != 4);
    }
    // Método para añadir la medicina con su nombre y precio a listaMedicina
    public static void añadirMedicina() {
        System.out.print("Ingrese el nombre de la medicina: ");
        String medicamento = scanner.nextLine();
        System.out.print("Ingrese el precio de la medicina: ");
        float precio = scanner.nextFloat();
        scanner.nextLine();  // Limpiar el buffer del scanner
        Medicina producto = new Medicina(medicamento, precio);
        listaMedicina.add(producto);
        System.out.println("Producto añadido exitosamente.");
    }
    // Método para eliminar elemento de listaMedicina (Usando remove)
    public static void eliminarMedicina() {
        System.out.print("Ingrese el nombre del medicamento a eliminar: ");
        String prod = scanner.nextLine();
        boolean encontrado = false;
        // Buscar el medicamento en la lista listaMedicina
        for (Medicina medicina : listaMedicina) {
            // Si lo encuentra se va a eliminar el medicamento
            if (medicina.getMedicina().equalsIgnoreCase(prod)) {
                // Función para eliminar la lista
                listaMedicina.remove(medicina);
                System.out.println("Producto eliminado exitosamente.");
                encontrado = true;
                break;
            }
        }
        // Si no lo encuentra nos va a indicar que el producto no se encontró
        if (!encontrado) {
            System.out.println("Producto no encontrado.");
        }
    }
    // Método para listar los medicamentos
    public static void listarMedicinas() {
        // Verificar si la lista está vacía
        if (listaMedicina.isEmpty()) {
            System.out.println("No hay productos en la lista.");
        } else {
            // Si no está vacía se mostrarán los elementos
            System.out.println("Lista de Productos:");
            for (Medicina medicina : listaMedicina) {
                System.out.println(medicina);
            }
        }
    }
}

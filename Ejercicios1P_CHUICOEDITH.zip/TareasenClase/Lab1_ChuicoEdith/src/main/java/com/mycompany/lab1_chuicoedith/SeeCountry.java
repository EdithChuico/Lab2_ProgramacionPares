package com.mycompany.lab1_chuicoedith;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;
public class SeeCountry extends Principal{
  public void seeCountry(String pais, JTable tabla){
     MongoClient mc = connectMongo();
      MongoDatabase db = getMongoDatabase(mc, "Lab1");
         MongoCollection <Document> clP=db.getCollection(pais);
         DefaultTableModel tabla1=new DefaultTableModel();
         tabla1.setColumnIdentifiers(new String []{"Atleta", "Pais", "Tiempo"});
         FindIterable <Document> documentos= clP.find();
         for (Document doc:documentos){
             tabla1.addRow(new Object[]{doc.get("Nombre del atleta"), doc.get("Nacionalidad"),doc.get("Tiempo")});
             tabla.setModel(tabla1);
          }}}

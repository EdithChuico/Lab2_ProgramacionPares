package com.mycompany.lab1_chuicoedith;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javax.swing.JTextField;
import org.bson.Document;
public class recordTime extends Principal{
    float total;
    String time;
    public void time(JTextField promedio){
       MongoClient mc = connectMongo();
        MongoDatabase db = getMongoDatabase(mc, "Lab1");
    MongoCollection<Document> cl = db.getCollection("Atletas");
    float prom=0;
    int cant=0;
    FindIterable<Document> iterable = cl.find();
    for (Document doc : iterable) {
        Integer tiempo = doc.getInteger("Tiempo");
        prom=tiempo+prom;
        cant++;
    }
    total=prom/cant;
    time= Float.toString(total);
    promedio.setText(time);  
    }
}

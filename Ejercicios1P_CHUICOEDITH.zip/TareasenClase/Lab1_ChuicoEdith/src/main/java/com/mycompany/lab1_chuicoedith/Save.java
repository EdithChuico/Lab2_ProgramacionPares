package com.mycompany.lab1_chuicoedith;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import org.bson.Document;
public class Save extends Principal{
    public void guardarAtleta(String name, String country, int time){
        MongoClient mc = connectMongo();
        MongoDatabase db = getMongoDatabase(mc, "Lab1");
         MongoCollection <Document> cl=db.getCollection("Atletas");
         MongoCollection <Document> clP=db.getCollection(country);
         Document doc=new Document().append("Nombre del atleta", name).append("Nacionalidad", country).append("Tiempo", time);
         cl.insertOne(doc);
         clP.insertOne(doc);
         JOptionPane.showMessageDialog(null, "Datos Guardados Exitosamente", "Exito", JOptionPane.INFORMATION_MESSAGE);
    }
     public List<String> obtenerProductos() {
	MongoClient mc = connectMongo();
        MongoDatabase db = getMongoDatabase(mc, "Lab1");
	MongoCollection<Document> collection = db.getCollection("Atletas");
	Set<String> datos = new HashSet<>();
	FindIterable<Document> result = collection.find();
	    try (MongoCursor<Document> cursor = result.iterator()) {
	        while (cursor.hasNext()) {
	            Document document = cursor.next();
	            String nombre = document.getString("Nacionalidad");
	            datos.add(nombre);}}
	    return new ArrayList<> (datos);
	}
     public void añadirProdComboBox(JComboBox Paises) {
	    List<String> datos = obtenerProductos();
	    DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>(datos.toArray(new String[0]));
	    Paises.setModel(model); 
	}}

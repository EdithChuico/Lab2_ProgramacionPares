package com.mycompany.lab1_chuicoedith;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
public class Principal {
    public MongoClient connectMongo() {
        return MongoClients.create("mongodb://localhost:27017/");
    }
    public MongoDatabase getMongoDatabase(MongoClient mc, String dbName) {
        return mc.getDatabase(dbName);
    }   
}

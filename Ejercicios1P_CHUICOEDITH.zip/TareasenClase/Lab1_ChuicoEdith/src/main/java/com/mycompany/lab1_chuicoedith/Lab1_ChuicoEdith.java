package com.mycompany.lab1_chuicoedith;
public class Lab1_ChuicoEdith {

    public static void main(String[] args) {
        IngresoDatos iD=new IngresoDatos();
        iD.setVisible(true);
        iD.setLocationRelativeTo(null);
    }
    
}

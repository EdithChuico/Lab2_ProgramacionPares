package com.mycompany.lab1_chuicoedith;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javax.swing.JTextField;
import org.bson.Document;
public class Champion extends Principal{
    public void seeChampion(JTextField nombre,JTextField pais,JTextField tiempo ){
        MongoClient mc = connectMongo();
        MongoDatabase db = getMongoDatabase(mc, "Lab1");
    MongoCollection<Document> cl = db.getCollection("Atletas");
    Document maxTimeDocument = null;
    int maxTime = Integer.MAX_VALUE;
    FindIterable<Document> iterable = cl.find();
    for (Document doc : iterable) {
        Integer tiempoo = doc.getInteger("Tiempo");
        if (tiempoo != null && tiempoo < maxTime) {
            maxTime = tiempoo;
            maxTimeDocument = doc;}}
    if (maxTimeDocument != null) {
        String nombree = maxTimeDocument.getString("Nombre del atleta");
        String paiss = maxTimeDocument.getString("Nacionalidad");
        int tiempoo = maxTimeDocument.getInteger("Tiempo");
        String time= Integer.toString(tiempoo);
         nombre.setText( nombree);
        pais.setText(paiss);
        tiempo.setText(time); }}}

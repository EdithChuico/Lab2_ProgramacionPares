package lista;
import Colas.Colas;
import java.util.Scanner;
import java.util.Stack;
public class Lista {
    public static void main(String[] args) {
        Scanner e= new Scanner(System.in);
        System.out.println("COLAS");
        Colas c=new Colas();
        c.ARREGLO();
        System.out.println("LISTAS");
        int tamaño;
        String colorr;
        System.out.println("Indique el tamanio de la lista");
        tamaño=e.nextInt();
        Nodo inicio = null;
        e.nextLine();
        for(int i=0; i<tamaño;i++){
        System.out.println("Engrese el nombre del " + (i+1) + " numero de la lista");
        colorr=e.nextLine();
        Nodo nuevoNodo = new Nodo(colorr);
        if(inicio==null){
            inicio=nuevoNodo;
        }else{
          Nodo nodoActual = inicio;
        while (nodoActual.next != null) {
            nodoActual = nodoActual.next;
        }   
        nodoActual.next=nuevoNodo;
        }
        }
        Nodo nodoActual = inicio;
        //Imprimir la lista de colores
        System.out.println("Lista creada");
        while (nodoActual != null) {
            System.out.println(nodoActual.color);
            nodoActual = nodoActual.next;
        }
        System.out.println("PILAS");
        Stack<String> pila = new Stack<>();

        System.out.println("Indique el tamaño de la pila:");
        int tamañoo = e.nextInt();
        e.nextLine();
        for (int i = 0; i < tamañoo; i++) {
            System.out.println("Indique el color del " + (i + 1) + " elemento de la pila:");
            
            String color = e.nextLine();
            pila.push(color);
        }

        // Imprimir la pila de colores
        System.out.println("Elementos de la pila:");
        while (!pila.isEmpty()) {
            System.out.println(pila.pop());
        }
    }
}
class Nodo {
    Nodo next;
    String color;
    Nodo(String color) {
        this.color = color;
    }
}
class Pila {
    int valor;
    Pila siguiente;

    Pila(int valor) {
        this.valor = valor;
        this.siguiente = null;
    }
    
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pila;

/**
 *
 * @author HP
 */
public class Pila {
    int valor;
    Pila siguiente;
     Pila(int valor){
     this.valor=valor;
     this.siguiente=null;
    }
}

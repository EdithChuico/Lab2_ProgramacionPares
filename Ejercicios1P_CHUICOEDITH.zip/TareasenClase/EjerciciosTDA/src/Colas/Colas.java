/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Colas;

import java.util.Scanner;

/**
 *
 * @author HP
 */
public class Colas {
    Scanner sc=new Scanner(System.in);
    public void dd(){
    System.out.println("Ingrese un valor para n");
    int i = 0;
    i=sc.nextInt(); 
        //System.out.println("Suma recursiva: " + sumaRecursiva(i, 0));
        System.out.println("Suma iterativa: " + sumaIterativa(i));
        
}
    public void ARREGLO(){
        int tamaño;
        int num=0;
      System.out.println("Ingrese el tamaño del arreglo: ");
            tamaño=sc.nextInt();
            int[]arreglo = new int[tamaño];
            System.out.println("Ingrese los valores para el arreglo: ");
            for(int i=0;i<tamaño;i++){
                System.out.println("Ingrese el valor: "+i);
                num=sc.nextInt();
            }
            for(int i=0;i<tamaño;i++){
             System.out.println("Los valores agregados son: "+ sumaRecursiva(  arreglo,  tamaño)  );   
            }
         
        
}
    //Solución recursiva
    int sumaRecursiva ( int []arreglo, int tamaño){
        for(int i=0; i<tamaño; i++){
        System.out.println(arreglo[i]);
        }return 
    }
    int sumaIterativa(int n){
        int suma=0;
        while (n>9){
            suma+=n%10;
            n/=10;
            
        } return (suma+n);
    }
}

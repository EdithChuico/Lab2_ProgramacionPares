package com.mycompany.listaa;

public class Pila {
    int valor;
    Pila siguiente;

    Pila(int valor) {
        this.valor = valor;
        this.siguiente = null;
    }
}


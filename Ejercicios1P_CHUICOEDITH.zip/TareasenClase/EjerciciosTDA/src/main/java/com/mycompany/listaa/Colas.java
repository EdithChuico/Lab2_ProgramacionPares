
package com.mycompany.listaa;

import java.util.Scanner;

public class Colas {
    Scanner sc = new Scanner(System.in);

    public void dd() {
        System.out.println("Ingrese un valor para n:");
        int i = sc.nextInt();
        // System.out.println("Suma recursiva: " + sumaRecursiva(i, 0));
        System.out.println("Suma iterativa: " + sumaIterativa(i));
    }

    public void ARREGLO() {
        int tamaño;
        int num = 0;
        System.out.println("Ingrese el tamaño del arreglo:");
        tamaño = sc.nextInt();
        int[] arreglo = new int[tamaño];

        System.out.println("Ingrese los valores para el arreglo:");
        for (int i = 0; i < tamaño; i++) {
            System.out.print("Ingrese el valor " + (i + 1) + ": ");
            num = sc.nextInt();
            arreglo[i] = num;
        }

        System.out.println("Los valores agregados son:");
        sumaRecursiva(arreglo, 0); // Llamada a sumaRecursiva para imprimir los valores
    }

    // Solución recursiva con impresión de elementos de arreglo
    void sumaRecursiva(int[] arreglo, int indice) {
        if (indice >= arreglo.length) {
            return; // Condición base: termina la recursión cuando el índice es igual o mayor que el tamaño del arreglo
        }
        System.out.println(arreglo[indice]); // Imprime el elemento actual
        sumaRecursiva(arreglo, indice + 1); // Llamada recursiva con incremento del índice
    }

    int sumaIterativa(int n) {
        int suma = 0;
        while (n > 9) {
            suma += n % 10;
            n /= 10;
        }
        return (suma + n);
    }
}

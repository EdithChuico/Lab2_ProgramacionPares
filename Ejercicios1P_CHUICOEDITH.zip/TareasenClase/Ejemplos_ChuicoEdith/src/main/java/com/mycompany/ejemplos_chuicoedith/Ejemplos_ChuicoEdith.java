package com.mycompany.ejemplos_chuicoedith;

import java.util.Random;
import java.util.Scanner;

public class Ejemplos_ChuicoEdith {

    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
         int ingreso;
        do{
        System.out.println("Indique el ejercicio que desee visualizar");
        System.out.println("1. Ejercicio 3.2");
        System.out.println("2. Ejercicio 3.3");
        System.out.println("3. Ejercicio 3.4");
        System.out.println("4. Ejercicio 3.5");
        System.out.println("5. Ejercicio 3.6");
        System.out.println("6. Ejercicio 3.7");
        System.out.println("7. Ejercicio 3.8");
        System.out.println("8. Ejercicio 3.9");
        System.out.println("9. Ejercicio 3.10");
        System.out.println("10. Ejercicio 3.11");
        System.out.println("11. Ejercicio 3.12");
        System.out.println("12. Ejercicio 3.13");
        System.out.println("13. Ejercicio 3.14");
        System.out.println("0. Salir");
        ingreso=s.nextInt();
        switch(ingreso){
        case 0:
            System.out.println("Saliendo");
        break;
        case 1:
            System.out.println("Ingrese 10 valores para el vector a");
            int a[] = new int [10];
            for(int i=0; i<10;i++){ 
            a[i]=s.nextInt();
            }
            System.out.println("El valor ingresado en la posición 2 es: ");
            System.out.println(a[2]);
        break;
        case 2:
            int []mes = new int[12];
            float salarios[] = new float[25]; 
            mes[4] = 5;
            int salario=mes[4]*3; 
            System.out.println("El salario en la posición " + salario + " es: " + salarios[salario]); 
            int Racional[] = new int [20]; 
            System.out.println("El elemento en la posición " + (20 - 4) + " del arreglo 'ra' es: " + Racional[20- 4]);
        break;
        case 3:
            int n;
            int num = 0;
            int res = 0;
            System.out.println("Ingrese el tamaño del arreglo: ");
            n=s.nextInt();
            int[]arreglo = new int[n];
            System.out.println("Ingrese los valores para el arreglo: ");
            for(int i=0;i<n;i++){
                System.out.println("Ingre el valor: "+i);
                 num=s.nextInt();
                res= res+num;
            }
            System.out.println("La suma de los valores en el arreglo es: " + res);
        break;
        case 4:
             double[] ar = new double[10];
        int resultados;
        try {
            resultados = datos(ar, s);
            System.out.println("Resultado: " + resultados);
        } catch (Exception e) {
            e.printStackTrace();
        }     break;
        case 5:
            int[] t = {1,3,5};
            int [] b = {2,4,6,8,10};
            int mtb[][] = {t, b};
            for (int i = 0; i < mtb.length; i++) {
                System.out.println("Fila " + i + ":");
                for (int j = 0; j < mtb[i].length; j++) {
                    System.out.print(mtb[i][j] + " ");
                }
                System.out.println();
            }
        break;
        case 6:
            double [][]gr = new double[3][];
            int [][]pres = new int[4][];
            gr[0] = new double[1];
            gr[1] = new double[2];
            gr[2] = new double[3];
            pres[0] = new int[]{2,3,6,7};
            pres[1] = new int[]{1,5,8};
            pres[2] = new int[]{5,14};
            pres[3] = new int[]{95};
            for (int i = 0; i < gr.length; i++) {
                System.out.println("Fila " + i + ":");
                for (int j = 0; j < gr[i].length; j++) {
                    System.out.print(gr[i][j] + " ");
                }
                System.out.println();
            }
            for (int i = 0; i < pres.length; i++) {
                System.out.println("Fila " + i + ":");
                for (int j = 0; j < pres[i].length; j++) {
                    System.out.print(pres[i][j] + " ");
                }
                System.out.println();
            }
        break;    
        case 7:
             int pagina, linea, columna;
            final int PAGINAS = 2;
            final int LINEAS = 4;
            final int COLUMNAS = 8;
            char libro[][][] = new char[PAGINAS][LINEAS][COLUMNAS];
            Random random = new Random();
            for (pagina = 0; pagina < PAGINAS; ++pagina) {
                for (linea = 0; linea < LINEAS; ++linea) {
                    for (columna = 0; columna < COLUMNAS; ++columna) {
                        libro[pagina][linea][columna] = (char) (random.nextInt(26) + 'A');
                    }
                }
            }
            for (pagina = 0; pagina < PAGINAS; ++pagina) {
                System.out.println("Página " + (pagina + 1) + ":");
                for (linea = 0; linea < LINEAS; ++linea) {
                    for (columna = 0; columna < COLUMNAS; ++columna) {
                        System.out.print(libro[pagina][linea][columna] + " ");
                    }
                    System.out.println(); 
                }
                System.out.println(); 
            }
        break;
        case 8:
            int[] arrayEnteros = {1, 2, 3, 4, 5};
            int ne = 3; 
            int resultado = SumaDeEnteros(arrayEnteros, ne);
            System.out.println("La suma de los primeros " + ne + " elementos del array es: " + resultado);
        break;
        case 9:
            char cad[] = {'S', 'u', 's', 'a', 'n', 'a'};
            for (int i=0;i<6;i++){
                System.out.print(cad[i]);
            }
            System.out.println(" ");
        break;
        case 10:
            String cad1 = "Sabado tarde", cad2;
            cad2 = new String(cad1);
            if (cad1.equals(cad2)) // esta condición es true
            System.out. println(cad1 + " = " + cad2);   
        break;
        case 11:
            String mayus;
            char[] vmay = new char[26];
            for (int j = 0; j < 26; j++)
                vmay[j] = (char) ('A' + j);
            mayus = new String(vmay);
            System.out.println("La cadena mayusculas es: " + mayus);
        break;
        case 12:
            String nombre="";
            System.out.println("Ingrese un nombre para verificar si es igual a Mariano");
            s.nextLine();
            nombre=s.nextLine();
            if (nombre.equals("Mariano" )) {
            System.out.println(nombre + " == Mariano : true" );
            System.out.println("Los objetos contienen lo mismo.");
            }else{
            System.out.println("Los objetos son diferentes.");    
            }
            break;
        case 13:
            String ch;
            ch = new String("Patatas a ");
            double x = 11.2;
            ch = ch + x + " Euros";
            String bg;
            bg = 2 + 4 + "Mares"; 
            bg = "Mares" + 2 + 4; 
            System.out.println(ch);
            System.out.println(bg);
            break;
        default:
            System.out.println("Ingrese un numero valido");
        }}while(ingreso!=0);
        
}
     static int SumaDeEnteros(int[]arrayEnteros, int ne){
            int i, sc;
            for (i = sc = 0; i < ne; ){
             sc += arrayEnteros[i++];
            }return sc;
            } 
     static int datos(double ar[], Scanner s) throws Exception {
        int e = 0;
        System.out.println("Entrada de datos, cuántos elementos: ? ");
        e = s.nextInt();
        if (e > ar.length)
            return 0;
        System.out.println("Ingrese los elementos:");
        for (int i = 0; i < e; i++)
            ar[i] = s.nextDouble();
        return 1;
    }
}

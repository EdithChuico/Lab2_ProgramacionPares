/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Operation;

import javax.swing.JTextField;


/**
 *
 * @author USER
 */
public abstract class Operations {
    public abstract void execute(JTextField cont, JTextField contPrice, double price);

    protected void updateFields(JTextField cont, JTextField contPrice, int newCont, double price) {
        String newContStr = String.valueOf(newCont);
        cont.setText(newContStr);
        double contPriceValue = newCont * price;
        contPrice.setText(String.valueOf(contPriceValue));
    }
}
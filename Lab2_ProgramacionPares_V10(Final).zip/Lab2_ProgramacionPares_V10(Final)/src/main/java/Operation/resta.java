/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Operation;

import javax.swing.JTextField;

/**
 *
 * @author USER
 */
public class resta extends Operations {
    @Override
    public void execute(JTextField cont, JTextField contPrice, double price) {
        int base = Integer.parseInt(cont.getText());
        int newCont = (base == 0) ? 0 : base - 1;
        updateFields(cont, contPrice, newCont, price);
    }
}

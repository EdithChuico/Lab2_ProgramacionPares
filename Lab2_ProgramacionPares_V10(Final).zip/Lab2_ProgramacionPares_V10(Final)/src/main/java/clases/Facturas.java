/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;

/**
 *
 * @author USER
 */
public class Facturas extends openMongo{
    public void guardarDatosMongo(JTable Carrito, JLabel lblUsuario, JLabel lblCedula) {
    // Obtén la colección donde se guardarán los datos
    openMongo();
    MongoDatabase database = getDatabase();
    MongoCollection<Document> collection = database.getCollection("Facturas");

    // Obtén el nombre del usuario y la cédula desde los JLabel
    String usuario = lblUsuario.getText();
    String cedula = lblCedula.getText();

    // Obtén el modelo de la tabla
    DefaultTableModel modelo = (DefaultTableModel) Carrito.getModel();

    // Lista para almacenar los productos
    List<String> productos = new ArrayList<>();
    double subtotal = 0.0;

    // Itera sobre las filas de la tabla
    for (int i = 0; i < modelo.getRowCount(); i++) {
        // Obtén el producto y el total
        String producto = (String) modelo.getValueAt(i, 0);
        double total = (double) modelo.getValueAt(i, 4); // Asumiendo que el total está en la columna 4

        // Agrega el producto a la lista
        productos.add(producto);

        // Suma el total al subtotal
        subtotal += total;
    }

    // Calcula el total con impuestos (asumiendo un 15% de impuesto)
    double totalConImpuesto = subtotal * 1.15;

    // Crea el documento a insertar en MongoDB
    Document documento = new Document("Usuario", usuario)
            .append("Cédula", cedula)
            .append("Pedidos", productos)
            .append("Subtotal", String.format("%.2f",subtotal))
            .append("Total", String.format("%.2f", totalConImpuesto));

    // Inserta el documento en la colección
    collection.insertOne(documento);

    // Mensaje de éxito
    JOptionPane.showMessageDialog(null, "Compra realizada con éxito", "AVISO", JOptionPane.INFORMATION_MESSAGE);
}
    public void actualizarTotales(JTable Carrito, JTextField txtSubtotal, JTextField txtTotalConImpuesto) {
    // Obtén el modelo de la tabla
    DefaultTableModel modelo = (DefaultTableModel) Carrito.getModel();
    
    // Inicializa las variables para la suma
    double subtotal = 0.0;

    // Itera sobre las filas de la tabla
    for (int i = 0; i < modelo.getRowCount(); i++) {
        // Obtén el valor de la columna "Total" (columna 4)
        Object valor = modelo.getValueAt(i, 4); // Asegúrate de que la columna correcta es la 4
        if (valor != null) {
            try {
                subtotal += Double.parseDouble(valor.toString());
            } catch (NumberFormatException e) {
                // Ignora los valores que no pueden convertirse a double
                System.err.println("Error al convertir el valor a double: " + valor);
            }
        }
    }

    // Asigna el subtotal al JTextField correspondiente
    txtSubtotal.setText(String.format("%.2f", subtotal));

    // Calcula el total con impuesto (15% adicional)
    double totalConImpuesto = subtotal * 1.15;

    // Asigna el total con impuesto al JTextField correspondiente
    txtTotalConImpuesto.setText(String.format("%.2f", totalConImpuesto));
}
}

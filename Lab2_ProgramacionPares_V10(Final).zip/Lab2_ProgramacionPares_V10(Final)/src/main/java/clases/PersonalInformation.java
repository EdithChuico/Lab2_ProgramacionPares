/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import org.bson.Document;


public class PersonalInformation extends openMongo{
    public void ShowInfo(JLabel jLabel25, JTextField UserName, JPasswordField UserContra, JTextField UserID, JTextField UserCell, JTextField UserCity){
        openMongo();
        MongoDatabase database = getDatabase();
        MongoCollection<Document> collection = database.getCollection("usuarios");
        Document filter = new Document("Usuario", jLabel25.getText());
        Document usuarios = collection.find(filter).first();

        String Usuario=usuarios.getString("Usuario");
        String Contrasena=usuarios.getString("Contraseña");
        String ID=usuarios.getString("Cédula");
        String Cell=usuarios.getString("Teléfono");
        String City=usuarios.getString("Ciudad");
        
        UserName.setText(Usuario);
        UserContra.setText(Contrasena);
        UserID.setText(ID);
        UserCell.setText(Cell);
        UserCity.setText(City);
    }
}

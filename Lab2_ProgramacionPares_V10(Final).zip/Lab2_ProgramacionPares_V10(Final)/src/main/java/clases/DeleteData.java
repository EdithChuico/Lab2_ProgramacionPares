/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author USER
 */
public class DeleteData {
    public void deleteProduct(JTable Carrito) {
        DefaultTableModel modelo = (DefaultTableModel) Carrito.getModel(); 
        // Obtener la fila seleccionada
        int filaSeleccionada = Carrito.getSelectedRow(); 
        // Verificar si se ha seleccionado una fila
        if (filaSeleccionada != -1) {
        // Eliminar la fila seleccionada del modelo
        modelo.removeRow(filaSeleccionada);
          } else {
        // Mostrar mensaje si no se ha seleccionado ninguna fila
        JOptionPane.showMessageDialog(null, "Seleccione un producto para eliminar", "¡AVISO!", JOptionPane.WARNING_MESSAGE);
        }
    }
    public void cancelar(JTable Carrito, JTextField subtotal, JTextField total) {
        DefaultTableModel modelo = (DefaultTableModel) Carrito.getModel();
        // Eliminar todas las filas del modelo
        modelo.setRowCount(0);
        subtotal.setText("");
        total.setText("");
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package boletos;

import javax.swing.JTextField;

/**
 *
 * @author USER
 */
class resta extends Boletos{
    public void restar(JTextField cont){
        int base=Integer.parseInt(cont.getText());
        int newCont=base-1;
        String NewCont=String.valueOf(newCont);
        cont.setText(NewCont);
    }
    @Override
    public void cantBoletos(double price, JTextField cont, JTextField contPrice){
       double totalBol = Double.parseDouble(cont.getText()) * price;
       contPrice.setText(String.valueOf(totalBol));
    }
}

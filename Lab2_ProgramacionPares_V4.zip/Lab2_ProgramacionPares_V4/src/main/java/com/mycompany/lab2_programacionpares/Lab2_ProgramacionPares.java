/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lab2_programacionpares;

/**
 *
 * @author HP
 */
public class Lab2_ProgramacionPares {

    public static void main(String[] args) {
        /*login l=new login();
        l.setVisible(true);
        l.setLocationRelativeTo(null);*/
        principal p=new principal();
        p.setVisible(true);
    }
}

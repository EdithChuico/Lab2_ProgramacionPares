/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import org.bson.Document;

/**
 *
 * @author USER
 */
public class AddData extends openMongo{
    public void addMovie(String pelicula, double price, JTextField cant, JTextField cantPrice, JComboBox Horario){
        if(Integer.parseInt(cant.getText())==0){
            JOptionPane.showMessageDialog(null, "NO SE HAN SELECCIONADO BOLETOS", "¡AVISO!", JOptionPane.ERROR_MESSAGE);
        }
        openMongo();
        MongoDatabase database = getDatabase();
        MongoCollection<Document> collection = database.getCollection("CarritoPeliculas");
        Document Pelicula = new Document("Pelicula", pelicula)
                .append("Boletos", Double.valueOf(cant.getText()))
                .append("Precio", price)
                .append("Total", Double.valueOf(cantPrice.getText()))
                .append("Horario",Horario.getSelectedItem().toString());
        collection.insertOne(Pelicula);
        JOptionPane.showMessageDialog(null, "Pedido agregago al carrito", "AVISO", JOptionPane.INFORMATION_MESSAGE);
    }
}

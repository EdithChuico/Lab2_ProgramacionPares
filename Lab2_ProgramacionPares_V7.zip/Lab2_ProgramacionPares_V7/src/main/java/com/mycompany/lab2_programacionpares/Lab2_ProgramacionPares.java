/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lab2_programacionpares;

/**
 *
 * @author HP
 */
public class Lab2_ProgramacionPares {

    public static void main(String[] args) {
        principal l=new principal();
        l.setVisible(true);
        l.setLocationRelativeTo(null);
    }
}

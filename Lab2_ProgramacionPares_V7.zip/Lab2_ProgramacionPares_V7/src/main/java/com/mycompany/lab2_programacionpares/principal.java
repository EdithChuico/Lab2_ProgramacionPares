/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.lab2_programacionpares;
import clases.Operations;
import clases.AddData;
import clases.deleteUsser;
import clases.loginU;
import clases.openMongo;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import org.bson.Document;
/**
 *
 * @author HP
 */
public class principal extends javax.swing.JFrame {
    Operations op=new Operations();
    AddData add=new AddData();
    /**
     * Creates new form principal
     */
    public principal() {
        initComponents();
        jPanel6.setVisible(true);
        jPanel4.setVisible(false);
        peliculas.setVisible(true);
        comida.setVisible(false);info.setVisible(false); usser.setVisible(false); 
        
        minus.setContentAreaFilled(false); 
        minus.setBorderPainted(false); 
        minus.setFocusPainted(false);
        minus.setOpaque(false);
        minus1.setContentAreaFilled(false); 
        minus1.setBorderPainted(false); 
        minus1.setFocusPainted(false);
        minus1.setOpaque(false);
        minus2.setContentAreaFilled(false); 
        minus2.setBorderPainted(false); 
        minus2.setFocusPainted(false);
        minus2.setOpaque(false);
        minus3.setContentAreaFilled(false); 
        minus3.setBorderPainted(false); 
        minus3.setFocusPainted(false);
        minus3.setOpaque(false);
        minus4.setContentAreaFilled(false); 
        minus4.setBorderPainted(false); 
        minus4.setFocusPainted(false);
        minus4.setOpaque(false);
        minus5.setContentAreaFilled(false); 
        minus5.setBorderPainted(false); 
        minus5.setFocusPainted(false);
        minus5.setOpaque(false);
        minus6.setContentAreaFilled(false); 
        minus6.setBorderPainted(false); 
        minus6.setFocusPainted(false);
        minus6.setOpaque(false);
        minus7.setContentAreaFilled(false); 
        minus7.setBorderPainted(false); 
        minus7.setFocusPainted(false);
        minus7.setOpaque(false);
        minus8.setContentAreaFilled(false); 
        minus8.setBorderPainted(false); 
        minus8.setFocusPainted(false);
        minus8.setOpaque(false);
        minus9.setContentAreaFilled(false); 
        minus9.setBorderPainted(false); 
        minus9.setFocusPainted(false);
        minus9.setOpaque(false);
        
        mas.setContentAreaFilled(false); 
        mas.setBorderPainted(false); 
        mas.setFocusPainted(false);
        mas.setOpaque(false);
        mas1.setContentAreaFilled(false); 
        mas1.setBorderPainted(false); 
        mas1.setFocusPainted(false);
        mas1.setOpaque(false);
        mas2.setContentAreaFilled(false); 
        mas2.setBorderPainted(false); 
        mas2.setFocusPainted(false);
        mas2.setOpaque(false);
        mas3.setContentAreaFilled(false); 
        mas3.setBorderPainted(false); 
        mas3.setFocusPainted(false);
        mas3.setOpaque(false);
        mas4.setContentAreaFilled(false); 
        mas4.setBorderPainted(false); 
        mas4.setFocusPainted(false);
        mas4.setOpaque(false);
        mas5.setContentAreaFilled(false); 
        mas5.setBorderPainted(false); 
        mas5.setFocusPainted(false);
        mas5.setOpaque(false);
        mas6.setContentAreaFilled(false); 
        mas6.setBorderPainted(false); 
        mas6.setFocusPainted(false);
        mas6.setOpaque(false);
        mas7.setContentAreaFilled(false); 
        mas7.setBorderPainted(false); 
        mas7.setFocusPainted(false);
        mas7.setOpaque(false);
        mas8.setContentAreaFilled(false); 
        mas8.setBorderPainted(false); 
        mas8.setFocusPainted(false);
        mas8.setOpaque(false);
        mas9.setContentAreaFilled(false); 
        mas9.setBorderPainted(false); 
        mas9.setFocusPainted(false);
        mas9.setOpaque(false);
        
        AddCarrito.setContentAreaFilled(false); 
        AddCarrito.setBorderPainted(false); 
        AddCarrito.setFocusPainted(false);
        AddCarrito.setOpaque(false);
        AddCarrito1.setContentAreaFilled(false); 
        AddCarrito1.setBorderPainted(false); 
        AddCarrito1.setFocusPainted(false);
        AddCarrito1.setOpaque(false);
        AddCarrito2.setContentAreaFilled(false); 
        AddCarrito2.setBorderPainted(false); 
        AddCarrito2.setFocusPainted(false);
        AddCarrito2.setOpaque(false);
        AddCarrito3.setContentAreaFilled(false); 
        AddCarrito3.setBorderPainted(false); 
        AddCarrito3.setFocusPainted(false);
        AddCarrito3.setOpaque(false);
        AddCarrito4.setContentAreaFilled(false); 
        AddCarrito4.setBorderPainted(false); 
        AddCarrito4.setFocusPainted(false);
        AddCarrito4.setOpaque(false);
        AddCarrito5.setContentAreaFilled(false); 
        AddCarrito5.setBorderPainted(false); 
        AddCarrito5.setFocusPainted(false);
        AddCarrito5.setOpaque(false);
        AddCarrito6.setContentAreaFilled(false); 
        AddCarrito6.setBorderPainted(false); 
        AddCarrito6.setFocusPainted(false);
        AddCarrito6.setOpaque(false);
        AddCarrito7.setContentAreaFilled(false); 
        AddCarrito7.setBorderPainted(false); 
        AddCarrito7.setFocusPainted(false);
        AddCarrito7.setOpaque(false);
        AddCarrito8.setContentAreaFilled(false); 
        AddCarrito8.setBorderPainted(false); 
        AddCarrito8.setFocusPainted(false);
        AddCarrito8.setOpaque(false);
        AddCarrito9.setContentAreaFilled(false); 
        AddCarrito9.setBorderPainted(false); 
        AddCarrito9.setFocusPainted(false);
        AddCarrito9.setOpaque(false);
       
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel12 = new javax.swing.JLabel();
        jComboBox3 = new javax.swing.JComboBox<>();
        jLabel13 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        perfil = new javax.swing.JButton();
        salir = new javax.swing.JButton();
        noticias = new javax.swing.JButton();
        bar = new javax.swing.JButton();
        cartelera = new javax.swing.JButton();
        peliculas = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        Horario = new javax.swing.JComboBox<>();
        Horario1 = new javax.swing.JComboBox<>();
        Horario2 = new javax.swing.JComboBox<>();
        Horario3 = new javax.swing.JComboBox<>();
        Horario4 = new javax.swing.JComboBox<>();
        Horario5 = new javax.swing.JComboBox<>();
        minus = new javax.swing.JButton();
        minus1 = new javax.swing.JButton();
        minus2 = new javax.swing.JButton();
        minus3 = new javax.swing.JButton();
        minus4 = new javax.swing.JButton();
        minus5 = new javax.swing.JButton();
        mas = new javax.swing.JButton();
        mas1 = new javax.swing.JButton();
        mas2 = new javax.swing.JButton();
        mas3 = new javax.swing.JButton();
        mas4 = new javax.swing.JButton();
        mas5 = new javax.swing.JButton();
        contPrice = new javax.swing.JTextField();
        cont = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        cont1 = new javax.swing.JTextField();
        cont2 = new javax.swing.JTextField();
        cont3 = new javax.swing.JTextField();
        cont4 = new javax.swing.JTextField();
        AddCarrito = new javax.swing.JButton();
        AddCarrito1 = new javax.swing.JButton();
        AddCarrito2 = new javax.swing.JButton();
        AddCarrito3 = new javax.swing.JButton();
        AddCarrito4 = new javax.swing.JButton();
        AddCarrito5 = new javax.swing.JButton();
        contPrice2 = new javax.swing.JTextField();
        contPrice1 = new javax.swing.JTextField();
        contPrice3 = new javax.swing.JTextField();
        contPrice4 = new javax.swing.JTextField();
        cont5 = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        contPrice5 = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox<>();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jComboBox4 = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        comida = new javax.swing.JScrollPane();
        jPanel2 = new javax.swing.JPanel();
        minus6 = new javax.swing.JButton();
        mas6 = new javax.swing.JButton();
        contPrice6 = new javax.swing.JTextField();
        cont6 = new javax.swing.JTextField();
        AddCarrito6 = new javax.swing.JButton();
        minus7 = new javax.swing.JButton();
        mas7 = new javax.swing.JButton();
        contPrice7 = new javax.swing.JTextField();
        cont7 = new javax.swing.JTextField();
        AddCarrito7 = new javax.swing.JButton();
        minus8 = new javax.swing.JButton();
        mas8 = new javax.swing.JButton();
        contPrice8 = new javax.swing.JTextField();
        cont8 = new javax.swing.JTextField();
        AddCarrito8 = new javax.swing.JButton();
        minus9 = new javax.swing.JButton();
        mas9 = new javax.swing.JButton();
        contPrice9 = new javax.swing.JTextField();
        cont9 = new javax.swing.JTextField();
        AddCarrito9 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        info = new javax.swing.JScrollPane();
        jPanel3 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        usser = new javax.swing.JScrollPane();
        jPanel5 = new javax.swing.JPanel();
        jButton4 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        idN = new javax.swing.JTextField();
        password = new javax.swing.JPasswordField();
        jButton3 = new javax.swing.JButton();
        jLabel20 = new javax.swing.JLabel();

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/posterP1.jpg"))); // NOI18N

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Lunes (13:00 H)", "Lunes (16:00 h)", "Martes (14:00 H)", "Martes (17:00 H)", "Miercoles (13:00 H)", "Miercoles (16:00 h)", "Jueves (14:00 H)", "Jueves (17:00 H)", "Viernes (13:00 H)", "Viernes (16:00 h)", "Sabado (14:00 H)", "Docmingo (17:00 H)" }));

        jLabel13.setText("BlackPim");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1366, 768));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        perfil.setBorder(null);
        perfil.setOpaque(false);
        perfil.setContentAreaFilled(false);
        perfil.setBorderPainted(false);
        perfil.setBorder(null);
        perfil.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        perfil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                perfilActionPerformed(evt);
            }
        });
        jPanel4.add(perfil, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 10, 80, 80));

        salir.setBorder(null);
        salir.setOpaque(false);
        salir.setContentAreaFilled(false);
        salir.setBorderPainted(false);
        salir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salirActionPerformed(evt);
            }
        });
        jPanel4.add(salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(1280, 10, 70, 80));

        noticias.setBorder(null);
        noticias.setOpaque(false);
        noticias.setContentAreaFilled(false);
        noticias.setBorderPainted(false);
        noticias.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        noticias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                noticiasActionPerformed(evt);
            }
        });
        jPanel4.add(noticias, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 10, 100, 80));

        bar.setBorder(null);
        bar.setOpaque(false);
        bar.setContentAreaFilled(false);
        bar.setBorderPainted(false);
        bar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        bar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                barActionPerformed(evt);
            }
        });
        jPanel4.add(bar, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 10, 90, 80));

        cartelera.setBorder(null);
        cartelera.setOpaque(false);
        cartelera.setContentAreaFilled(false);
        cartelera.setBorderPainted(false);
        cartelera.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cartelera.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                carteleraActionPerformed(evt);
            }
        });
        jPanel4.add(cartelera, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 20, 90, 70));

        peliculas.setPreferredSize(new java.awt.Dimension(1366, 693));

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Horario.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Horario.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Lunes (13:00 H)", "Lunes (16:00 h)", "Martes (14:00 H)", "Martes (17:00 H)", "Miercoles (13:00 H)", "Miercoles (16:00 h)", "Jueves (14:00 H)", "Jueves (17:00 H)", "Viernes (13:00 H)", "Viernes (16:00 h)", "Sabado (14:00 H)", "Docmingo (17:00 H)" }));
        Horario.setBorder(null);
        Horario.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        Horario.setFocusable(false);
        Horario.setLightWeightPopupEnabled(false);
        Horario.setRequestFocusEnabled(false);
        jPanel1.add(Horario, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 270, 330, 40));

        Horario1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Lunes (13:00 H)", "Lunes (16:00 h)", "Martes (14:00 H)", "Martes (17:00 H)", "Miercoles (13:00 H)", "Miercoles (16:00 h)", "Jueves (14:00 H)", "Jueves (17:00 H)", "Viernes (13:00 H)", "Viernes (16:00 h)", "Sabado (14:00 H)", "Docmingo (17:00 H)" }));
        jPanel1.add(Horario1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 590, 160, 30));

        Horario2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Lunes (13:00 H)", "Lunes (16:00 h)", "Martes (14:00 H)", "Martes (17:00 H)", "Miercoles (13:00 H)", "Miercoles (16:00 h)", "Jueves (14:00 H)", "Jueves (17:00 H)", "Viernes (13:00 H)", "Viernes (16:00 h)", "Sabado (14:00 H)", "Docmingo (17:00 H)" }));
        jPanel1.add(Horario2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 870, 160, 30));

        Horario3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Lunes (13:00 H)", "Lunes (16:00 h)", "Martes (14:00 H)", "Martes (17:00 H)", "Miercoles (13:00 H)", "Miercoles (16:00 h)", "Jueves (14:00 H)", "Jueves (17:00 H)", "Viernes (13:00 H)", "Viernes (16:00 h)", "Sabado (14:00 H)", "Docmingo (17:00 H)" }));
        jPanel1.add(Horario3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 1180, 160, 30));

        Horario4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Lunes (13:00 H)", "Lunes (16:00 h)", "Martes (14:00 H)", "Martes (17:00 H)", "Miercoles (13:00 H)", "Miercoles (16:00 h)", "Jueves (14:00 H)", "Jueves (17:00 H)", "Viernes (13:00 H)", "Viernes (16:00 h)", "Sabado (14:00 H)", "Docmingo (17:00 H)" }));
        jPanel1.add(Horario4, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 1450, 160, 30));

        Horario5.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Lunes (13:00 H)", "Lunes (16:00 h)", "Martes (14:00 H)", "Martes (17:00 H)", "Miercoles (13:00 H)", "Miercoles (16:00 h)", "Jueves (14:00 H)", "Jueves (17:00 H)", "Viernes (13:00 H)", "Viernes (16:00 h)", "Sabado (14:00 H)", "Docmingo (17:00 H)" }));
        jPanel1.add(Horario5, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 1760, 160, 30));

        minus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minusActionPerformed(evt);
            }
        });
        jPanel1.add(minus, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 320, 40, 40));

        minus1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minus1ActionPerformed(evt);
            }
        });
        jPanel1.add(minus1, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 640, 40, 40));

        minus2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minus2ActionPerformed(evt);
            }
        });
        jPanel1.add(minus2, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 910, 40, 40));

        minus3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minus3ActionPerformed(evt);
            }
        });
        jPanel1.add(minus3, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 1230, 40, 40));

        minus4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minus4ActionPerformed(evt);
            }
        });
        jPanel1.add(minus4, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 1490, 40, 40));

        minus5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minus5ActionPerformed(evt);
            }
        });
        jPanel1.add(minus5, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 1810, 40, 40));

        mas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                masActionPerformed(evt);
            }
        });
        jPanel1.add(mas, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 320, 40, 40));

        mas1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mas1ActionPerformed(evt);
            }
        });
        jPanel1.add(mas1, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 640, 40, 40));

        mas2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mas2ActionPerformed(evt);
            }
        });
        jPanel1.add(mas2, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 910, 40, 40));

        mas3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mas3ActionPerformed(evt);
            }
        });
        jPanel1.add(mas3, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 1230, 40, 40));

        mas4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mas4ActionPerformed(evt);
            }
        });
        jPanel1.add(mas4, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 1490, 40, 40));

        mas5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mas5ActionPerformed(evt);
            }
        });
        jPanel1.add(mas5, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 1810, 40, 40));

        contPrice.setBackground(new java.awt.Color(0, 0, 0));
        contPrice.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        contPrice.setForeground(new java.awt.Color(255, 255, 255));
        contPrice.setBorder(null);
        jPanel1.add(contPrice, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 380, 80, 30));

        cont.setBackground(new java.awt.Color(248, 194, 30));
        cont.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        cont.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        cont.setText("0");
        cont.setBorder(null);
        jPanel1.add(cont, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 320, 50, 40));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("TOTAL:");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 1870, 80, 30));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("TOTAL:");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 380, 80, 30));

        cont1.setBackground(new java.awt.Color(248, 194, 30));
        cont1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        cont1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        cont1.setText("0");
        cont1.setBorder(null);
        jPanel1.add(cont1, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 640, 50, 40));

        cont2.setBackground(new java.awt.Color(248, 194, 30));
        cont2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        cont2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        cont2.setText("0");
        cont2.setBorder(null);
        jPanel1.add(cont2, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 920, 50, 30));

        cont3.setBackground(new java.awt.Color(248, 194, 30));
        cont3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        cont3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        cont3.setText("0");
        cont3.setBorder(null);
        jPanel1.add(cont3, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 1240, 50, 30));

        cont4.setBackground(new java.awt.Color(248, 194, 30));
        cont4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        cont4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        cont4.setText("0");
        cont4.setBorder(null);
        jPanel1.add(cont4, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 1490, 50, 40));

        AddCarrito.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddCarritoActionPerformed(evt);
            }
        });
        jPanel1.add(AddCarrito, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 370, 290, 40));

        AddCarrito1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddCarrito1ActionPerformed(evt);
            }
        });
        jPanel1.add(AddCarrito1, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 690, 290, 40));

        AddCarrito2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddCarrito2ActionPerformed(evt);
            }
        });
        jPanel1.add(AddCarrito2, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 960, 290, 40));

        AddCarrito3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddCarrito3ActionPerformed(evt);
            }
        });
        jPanel1.add(AddCarrito3, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 1250, 290, 40));

        AddCarrito4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddCarrito4ActionPerformed(evt);
            }
        });
        jPanel1.add(AddCarrito4, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 1540, 290, 40));

        AddCarrito5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddCarrito5ActionPerformed(evt);
            }
        });
        jPanel1.add(AddCarrito5, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 1830, 290, 40));

        contPrice2.setBackground(new java.awt.Color(0, 0, 0));
        contPrice2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        contPrice2.setForeground(new java.awt.Color(255, 255, 255));
        contPrice2.setBorder(null);
        jPanel1.add(contPrice2, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 990, 80, 30));

        contPrice1.setBackground(new java.awt.Color(0, 0, 0));
        contPrice1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        contPrice1.setForeground(new java.awt.Color(255, 255, 255));
        contPrice1.setBorder(null);
        jPanel1.add(contPrice1, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 710, 80, 30));

        contPrice3.setBackground(new java.awt.Color(0, 0, 0));
        contPrice3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        contPrice3.setForeground(new java.awt.Color(255, 255, 255));
        contPrice3.setBorder(null);
        jPanel1.add(contPrice3, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 1300, 80, 30));

        contPrice4.setBackground(new java.awt.Color(0, 0, 0));
        contPrice4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        contPrice4.setForeground(new java.awt.Color(255, 255, 255));
        contPrice4.setBorder(null);
        jPanel1.add(contPrice4, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 1560, 80, 30));

        cont5.setBackground(new java.awt.Color(248, 194, 30));
        cont5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        cont5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        cont5.setText("0");
        cont5.setBorder(null);
        jPanel1.add(cont5, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 1810, 50, 40));

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("TOTAL:");
        jPanel1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 710, 80, 30));

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("TOTAL:");
        jPanel1.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 1300, 80, 30));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/inicioCartelera.png"))); // NOI18N
        jLabel5.setText("jLabel5");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1366, 175));

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("TOTAL:");
        jPanel1.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 1560, 80, 30));

        contPrice5.setBackground(new java.awt.Color(0, 0, 0));
        contPrice5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        contPrice5.setForeground(new java.awt.Color(255, 255, 255));
        contPrice5.setBorder(null);
        jPanel1.add(contPrice5, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 1870, 80, 30));

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("TOTAL:");
        jPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 990, 80, 30));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Poster1,2.jpeg"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 180, -1, -1));

        jLabel3.setText("jLabel3");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 660, -1, -1));

        jLabel8.setText("jLabel8");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 720, -1, -1));

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Lunes (13:00 H)", "Lunes (16:00 h)", "Martes (14:00 H)", "Martes (17:00 H)", "Miercoles (13:00 H)", "Miercoles (16:00 h)", "Jueves (14:00 H)", "Jueves (17:00 H)", "Viernes (13:00 H)", "Viernes (16:00 h)", "Sabado (14:00 H)", "Docmingo (17:00 H)" }));
        jPanel1.add(jComboBox2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 490, 160, 30));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Poester3.4.jpg"))); // NOI18N
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 770, 1370, 570));

        jLabel15.setText("BlackPim");
        jPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 710, -1, -1));

        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Lunes (13:00 H)", "Lunes (16:00 h)", "Martes (14:00 H)", "Martes (17:00 H)", "Miercoles (13:00 H)", "Miercoles (16:00 h)", "Jueves (14:00 H)", "Jueves (17:00 H)", "Viernes (13:00 H)", "Viernes (16:00 h)", "Sabado (14:00 H)", "Docmingo (17:00 H)" }));
        jPanel1.add(jComboBox4, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 740, 160, 30));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/poster5,6.png"))); // NOI18N
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 1340, 1370, 570));

        peliculas.setViewportView(jPanel1);

        jPanel4.add(peliculas, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 111, 1366, 660));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/subprin.jpeg"))); // NOI18N
        jPanel4.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 110));

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        minus6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minus6ActionPerformed(evt);
            }
        });
        jPanel2.add(minus6, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 120, 40, 40));

        mas6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mas6ActionPerformed(evt);
            }
        });
        jPanel2.add(mas6, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 120, 40, 40));

        contPrice6.setBackground(new java.awt.Color(138, 108, 163));
        contPrice6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        contPrice6.setBorder(null);
        jPanel2.add(contPrice6, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 130, 90, 20));

        cont6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        cont6.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        cont6.setText("0");
        cont6.setBorder(null);
        jPanel2.add(cont6, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 130, 50, 20));

        AddCarrito6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddCarrito6ActionPerformed(evt);
            }
        });
        jPanel2.add(AddCarrito6, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 80, 220, 50));

        minus7.setText("-");
        minus7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minus7ActionPerformed(evt);
            }
        });
        jPanel2.add(minus7, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 260, 40, 40));

        mas7.setText("+");
        mas7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mas7ActionPerformed(evt);
            }
        });
        jPanel2.add(mas7, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 260, 40, 40));

        contPrice7.setBackground(new java.awt.Color(138, 108, 163));
        contPrice7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        contPrice7.setBorder(null);
        jPanel2.add(contPrice7, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 270, 80, 20));

        cont7.setText("0");
        jPanel2.add(cont7, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 260, 50, 40));

        AddCarrito7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddCarrito7ActionPerformed(evt);
            }
        });
        jPanel2.add(AddCarrito7, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 220, 220, 50));

        minus8.setText("-");
        minus8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minus8ActionPerformed(evt);
            }
        });
        jPanel2.add(minus8, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 400, 40, 40));

        mas8.setText("+");
        mas8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mas8ActionPerformed(evt);
            }
        });
        jPanel2.add(mas8, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 400, 40, 40));

        contPrice8.setBackground(new java.awt.Color(138, 108, 163));
        contPrice8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        contPrice8.setBorder(null);
        jPanel2.add(contPrice8, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 410, 80, 20));

        cont8.setText("0");
        jPanel2.add(cont8, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 400, 50, 40));

        AddCarrito8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddCarrito8ActionPerformed(evt);
            }
        });
        jPanel2.add(AddCarrito8, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 360, 220, 50));

        minus9.setText("-");
        minus9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minus9ActionPerformed(evt);
            }
        });
        jPanel2.add(minus9, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 540, 40, 40));

        mas9.setText("+");
        mas9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mas9ActionPerformed(evt);
            }
        });
        jPanel2.add(mas9, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 540, 40, 40));

        contPrice9.setBackground(new java.awt.Color(138, 108, 163));
        contPrice9.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        contPrice9.setBorder(null);
        jPanel2.add(contPrice9, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 550, 80, 20));

        cont9.setText("0");
        jPanel2.add(cont9, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 540, 50, 40));

        AddCarrito9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddCarrito9ActionPerformed(evt);
            }
        });
        jPanel2.add(AddCarrito9, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 500, 220, 50));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/comidaFond.png"))); // NOI18N
        jLabel6.setText("jLabel5");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 0, 1366, 650));

        comida.setViewportView(jPanel2);

        jPanel4.add(comida, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 111, 1366, 660));

        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/info.png"))); // NOI18N
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 660));

        jLabel1.setText("Descuentos");
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 90, -1, -1));

        info.setViewportView(jPanel3);

        jPanel4.add(info, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 111, 1366, 660));

        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton4.setBorder(null);
        jButton4.setOpaque(false);
        jButton4.setContentAreaFilled(false);
        jButton4.setBorderPainted(false);
        jButton4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 450, 360, 50));

        jButton6.setBorder(null);
        jButton6.setOpaque(false);
        jButton6.setContentAreaFilled(false);
        jButton6.setBorderPainted(false);
        jPanel5.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 230, 240, 50));

        jButton5.setBorder(null);
        jButton5.setOpaque(false);
        jButton5.setContentAreaFilled(false);
        jButton5.setBorderPainted(false);
        jButton5.setText(" ");
        jButton5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 560, 310, 50));

        jButton7.setBorder(null);
        jButton7.setOpaque(false);
        jButton7.setContentAreaFilled(false);
        jButton7.setBorderPainted(false);
        jPanel5.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 330, 590, 50));

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setText("jLabel21");
        jPanel5.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 90, 300, 40));

        jLabel22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Usser.png"))); // NOI18N
        jLabel22.setText("Descuentos");
        jPanel5.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1370, 660));

        usser.setViewportView(jPanel5);

        jPanel4.add(usser, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 111, 1366, 660));

        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1370, 770));

        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setBackground(new java.awt.Color(0, 0, 0));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("X");
        jButton1.setBorder(null);
        jButton1.setBorderPainted(false);
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.setFocusPainted(false);
        jButton1.setFocusable(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel6.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1300, 20, 40, 40));

        jButton2.setBorder(null);
        jButton2.setOpaque(false);
        jButton2.setContentAreaFilled(false);
        jButton2.setBorderPainted(false);
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel6.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 550, 180, 40));

        idN.setBorder(null);
        jPanel6.add(idN, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 380, 450, 30));

        password.setBorder(null);
        jPanel6.add(password, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 490, 440, 30));

        jButton3.setBorder(null);
        jButton3.setOpaque(false);
        jButton3.setContentAreaFilled(false);
        jButton3.setBorderPainted(false);
        jButton3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel6.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 640, 150, 30));

        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/login.jpeg"))); // NOI18N
        jPanel6.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        getContentPane().add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1370, 770));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void noticiasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_noticiasActionPerformed
    peliculas.setVisible(false);
        comida.setVisible(false);info.setVisible(true); usser.setVisible(false);   // TODO add your handling code here:
    }//GEN-LAST:event_noticiasActionPerformed

    private void barActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_barActionPerformed
     peliculas.setVisible(false);
        comida.setVisible(true);info.setVisible(false);usser.setVisible(false);   // TODO add your handling code here:
    }//GEN-LAST:event_barActionPerformed

    private void carteleraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_carteleraActionPerformed
     peliculas.setVisible(true);
        comida.setVisible(false);info.setVisible(false); 
        usser.setVisible(false);// TODO add your handling code here:
    }//GEN-LAST:event_carteleraActionPerformed

    private void salirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salirActionPerformed
     System.exit(0);   // TODO add your handling code here:
    }//GEN-LAST:event_salirActionPerformed

    private void masActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_masActionPerformed
        op.suma(cont, contPrice, 7.50);       
    }//GEN-LAST:event_masActionPerformed

    private void minusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minusActionPerformed
        op.resta(cont, contPrice, 7.50);// TODO add your handling code here:
    }//GEN-LAST:event_minusActionPerformed

    private void minus1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minus1ActionPerformed
        op.resta(cont1, contPrice1, 7.50);// TODO add your handling code here:
    }//GEN-LAST:event_minus1ActionPerformed

    private void mas1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mas1ActionPerformed
        op.suma(cont1, contPrice1, 7.50);// TODO add your handling code here:
    }//GEN-LAST:event_mas1ActionPerformed

    private void minus2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minus2ActionPerformed
        op.resta(cont2, contPrice2, 7.00);// TODO add your handling code here:
    }//GEN-LAST:event_minus2ActionPerformed

    private void mas2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mas2ActionPerformed
        op.suma(cont2, contPrice2, 7.00);// TODO add your handling code here:
    }//GEN-LAST:event_mas2ActionPerformed

    private void minus3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minus3ActionPerformed
       op.resta(cont3, contPrice3, 7.50); // TODO add your handling code here:
    }//GEN-LAST:event_minus3ActionPerformed

    private void mas3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mas3ActionPerformed
        op.suma(cont3, contPrice3, 7.50);// TODO add your handling code here:
    }//GEN-LAST:event_mas3ActionPerformed

    private void minus4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minus4ActionPerformed
        op.resta(cont4, contPrice4, 7.50);// TODO add your handling code here:
    }//GEN-LAST:event_minus4ActionPerformed

    private void mas4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mas4ActionPerformed
        op.suma(cont4, contPrice4, 7.50);// TODO add your handling code here:
    }//GEN-LAST:event_mas4ActionPerformed

    private void mas5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mas5ActionPerformed
        op.suma(cont5, contPrice5, 7.00);// TODO add your handling code here:
    }//GEN-LAST:event_mas5ActionPerformed

    private void minus5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minus5ActionPerformed
        op.resta(cont5, contPrice5, 7.00);// TODO add your handling code here:
    }//GEN-LAST:event_minus5ActionPerformed

    private void AddCarritoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddCarritoActionPerformed
        add.addMovie("Coraline", 7.50, cont, contPrice, Horario);// TODO add your handling code here:
    }//GEN-LAST:event_AddCarritoActionPerformed

    private void AddCarrito1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddCarrito1ActionPerformed
        add.addMovie("Intensamente", 7.50, cont1, contPrice1, Horario1);// TODO add your handling code here:
    }//GEN-LAST:event_AddCarrito1ActionPerformed

    private void AddCarrito2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddCarrito2ActionPerformed
        add.addMovie("DEADPOOL & WOLVERINE", 7.00, cont2, contPrice2, Horario2);// TODO add your handling code here:
    }//GEN-LAST:event_AddCarrito2ActionPerformed

    private void AddCarrito3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddCarrito3ActionPerformed
        add.addMovie("Un lugar en silencio", 7.50, cont3, contPrice3, Horario3);// TODO add your handling code here:
    }//GEN-LAST:event_AddCarrito3ActionPerformed

    private void AddCarrito4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddCarrito4ActionPerformed
        add.addMovie("Bad Boys: hasta la muerte", 7.50, cont4, contPrice4, Horario4);// TODO add your handling code here:
    }//GEN-LAST:event_AddCarrito4ActionPerformed

    private void AddCarrito5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddCarrito5ActionPerformed
        add.addMovie("Mi villano favorito 4", 7.00, cont5, contPrice5, Horario5);// TODO add your handling code here:
    }//GEN-LAST:event_AddCarrito5ActionPerformed

    private void minus6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minus6ActionPerformed
        op.resta(cont6, contPrice6, 4.50);// TODO add your handling code here:
    }//GEN-LAST:event_minus6ActionPerformed

    private void mas6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mas6ActionPerformed
        op.suma(cont6, contPrice6, 4.50);// TODO add your handling code here:
    }//GEN-LAST:event_mas6ActionPerformed

    private void AddCarrito6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddCarrito6ActionPerformed
        add.addFood("CANGUIL GRANDE", "1 CANGUIL GRANDE", 4.50, cont6, contPrice6);// TODO add your handling code here:
    }//GEN-LAST:event_AddCarrito6ActionPerformed

    private void minus7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minus7ActionPerformed
        op.resta(cont7, contPrice7, 2.70);// TODO add your handling code here:
    }//GEN-LAST:event_minus7ActionPerformed

    private void mas7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mas7ActionPerformed
        op.suma(cont7, contPrice7, 2.70);// TODO add your handling code here:
    }//GEN-LAST:event_mas7ActionPerformed

    private void AddCarrito7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddCarrito7ActionPerformed
        add.addFood("bEBIDA DE 22", "1 BEBIDA DE 22 ONZAS", 2.70, cont7, contPrice7);// TODO add your handling code here:
    }//GEN-LAST:event_AddCarrito7ActionPerformed

    private void minus8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minus8ActionPerformed
        op.resta(cont8, contPrice8, 2.50);// TODO add your handling code here:
    }//GEN-LAST:event_minus8ActionPerformed

    private void mas8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mas8ActionPerformed
        op.suma(cont8, contPrice8, 2.50);// TODO add your handling code here:
    }//GEN-LAST:event_mas8ActionPerformed

    private void AddCarrito8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddCarrito8ActionPerformed
        add.addFood("CHOCOLATE MILKY WAY", "1 CHOCOLATE GRANDE", 2.50, cont8, contPrice8);// TODO add your handling code here:
    }//GEN-LAST:event_AddCarrito8ActionPerformed

    private void minus9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minus9ActionPerformed
        op.resta(cont9, contPrice9, 4.65);// TODO add your handling code here:
    }//GEN-LAST:event_minus9ActionPerformed

    private void mas9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mas9ActionPerformed
        op.suma(cont9, contPrice9, 4.65);// TODO add your handling code here:
    }//GEN-LAST:event_mas9ActionPerformed

    private void AddCarrito9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddCarrito9ActionPerformed
        add.addFood("SUPER NACHO", "1 NACHO GRANDE || 1 SALSA DE QUESO", 4.65, cont9, contPrice9);// TODO add your handling code here:
    }//GEN-LAST:event_AddCarrito9ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        System.exit(0);   // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        String Password = password.getText();
        String id=idN.getText();
        loginU l=new loginU();
        l.controlDatos(id, Password, jPanel6,jPanel4);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        newUsser l=new newUsser();
        l.setVisible(true);
        this.dispose(); // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void perfilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_perfilActionPerformed
         peliculas.setVisible(false);
        comida.setVisible(false);info.setVisible(false); usser.setVisible(true);
        String id=idN.getText();
         
        openMongo iM = new openMongo();
        iM.openMongo();
        MongoDatabase database = iM.getDatabase();
        MongoCollection<Document> collection = database.getCollection("usuarios");
        Document query = new Document("Cédula", id);
    long count= collection.countDocuments(query);
        if(count<=0){
            JOptionPane.showMessageDialog(null, "La cedula ingresada no esta registrada", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }else{
         Document userDoc = collection.find(query).first();
        if (userDoc != null) {
            String nombre = userDoc.getString("Usuario");
            jLabel21.setText( nombre.toUpperCase());
        }
        }
        
// TODO add your handling code here:
    }//GEN-LAST:event_perfilActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
     String id=idN.getText();
     deleteUsser d=new deleteUsser();
     d.deleteClient(id,this,jPanel6, jPanel4,password, idN);
    // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
       password.setText("");
       idN.setText("");
        jPanel6.setVisible(true);
        jPanel4.setVisible(false); // TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new principal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddCarrito;
    private javax.swing.JButton AddCarrito1;
    private javax.swing.JButton AddCarrito2;
    private javax.swing.JButton AddCarrito3;
    private javax.swing.JButton AddCarrito4;
    private javax.swing.JButton AddCarrito5;
    private javax.swing.JButton AddCarrito6;
    private javax.swing.JButton AddCarrito7;
    private javax.swing.JButton AddCarrito8;
    private javax.swing.JButton AddCarrito9;
    private javax.swing.JComboBox<String> Horario;
    private javax.swing.JComboBox<String> Horario1;
    private javax.swing.JComboBox<String> Horario2;
    private javax.swing.JComboBox<String> Horario3;
    private javax.swing.JComboBox<String> Horario4;
    private javax.swing.JComboBox<String> Horario5;
    private javax.swing.JButton bar;
    private javax.swing.JButton cartelera;
    private javax.swing.JScrollPane comida;
    private javax.swing.JTextField cont;
    private javax.swing.JTextField cont1;
    private javax.swing.JTextField cont2;
    private javax.swing.JTextField cont3;
    private javax.swing.JTextField cont4;
    private javax.swing.JTextField cont5;
    private javax.swing.JTextField cont6;
    private javax.swing.JTextField cont7;
    private javax.swing.JTextField cont8;
    private javax.swing.JTextField cont9;
    private javax.swing.JTextField contPrice;
    private javax.swing.JTextField contPrice1;
    private javax.swing.JTextField contPrice2;
    private javax.swing.JTextField contPrice3;
    private javax.swing.JTextField contPrice4;
    private javax.swing.JTextField contPrice5;
    private javax.swing.JTextField contPrice6;
    private javax.swing.JTextField contPrice7;
    private javax.swing.JTextField contPrice8;
    private javax.swing.JTextField contPrice9;
    private javax.swing.JTextField idN;
    private javax.swing.JScrollPane info;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JComboBox<String> jComboBox4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JButton mas;
    private javax.swing.JButton mas1;
    private javax.swing.JButton mas2;
    private javax.swing.JButton mas3;
    private javax.swing.JButton mas4;
    private javax.swing.JButton mas5;
    private javax.swing.JButton mas6;
    private javax.swing.JButton mas7;
    private javax.swing.JButton mas8;
    private javax.swing.JButton mas9;
    private javax.swing.JButton minus;
    private javax.swing.JButton minus1;
    private javax.swing.JButton minus2;
    private javax.swing.JButton minus3;
    private javax.swing.JButton minus4;
    private javax.swing.JButton minus5;
    private javax.swing.JButton minus6;
    private javax.swing.JButton minus7;
    private javax.swing.JButton minus8;
    private javax.swing.JButton minus9;
    private javax.swing.JButton noticias;
    private javax.swing.JPasswordField password;
    private javax.swing.JScrollPane peliculas;
    private javax.swing.JButton perfil;
    private javax.swing.JButton salir;
    private javax.swing.JScrollPane usser;
    // End of variables declaration//GEN-END:variables
}

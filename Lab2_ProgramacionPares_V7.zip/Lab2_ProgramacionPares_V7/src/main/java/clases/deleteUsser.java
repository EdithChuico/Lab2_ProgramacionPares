/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import java.awt.Component;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import org.bson.Document;

/**
 *
 * @author HP
 */
public class deleteUsser {
    openMongo iM = new openMongo();
     public void deleteClient(String id, Component componente, JPanel jPanel6, JPanel jPanel4, JPasswordField password, JTextField idN){
        iM.openMongo();
        MongoDatabase database = iM.getDatabase();
        MongoCollection<Document> collection = database.getCollection("usuarios");
        Document filter = new Document("Cédula", id);
        FindIterable<Document> result = collection.find(filter);
        if (result.iterator().hasNext()) {
            int respuesta = JOptionPane.showConfirmDialog(componente, "Se eliminaran todos los datos no guardados, ¿está seguro que desea continuar?", "Confirmar", JOptionPane.YES_NO_OPTION);

        if (respuesta == JOptionPane.YES_OPTION) {
            collection.deleteOne(filter);
            JOptionPane.showMessageDialog(null, "Se a eliminado el usuario correctamente", "Exito", JOptionPane.INFORMATION_MESSAGE);
            password.setText("");
            idN.setText("");
            jPanel6.setVisible(true);
        jPanel4.setVisible(false);
        }
}
     }
}

